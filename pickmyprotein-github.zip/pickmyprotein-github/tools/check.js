/* Optional safety check. Run:  node tools/check.js
   It checks that every product has the fields it needs, every picture file exists,
   and every link between your pages points to a file that exists. */
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const read = (f) => fs.readFileSync(path.join(root, f), "utf8");

const data = new Function(read("js/products.js") + "; return { SITE, POWDERS, PRODUCTS };")();
let problems = 0;
const fail = (msg) => { problems++; console.log("PROBLEM: " + msg); };

const powderIds = data.POWDERS.map((p) => p.id);
Object.keys(data.PRODUCTS).forEach((type) => {
  if (!powderIds.includes(type)) fail('PRODUCTS has "' + type + '" but POWDERS has no type with that id');
  data.PRODUCTS[type].forEach((p) => {
    ["brand", "name", "flavour", "asin", "linkId"].forEach((k) => { if (!p[k]) fail(p.name + " is missing " + k); });
    if (!["raw", "flavoured"].includes(p.flavour)) fail(p.name + ': flavour must be "raw" or "flavoured"');
    if (p.asin && !/^[A-Z0-9]{10}$/.test(p.asin)) fail(p.name + ": asin should be 10 letters/numbers");
    if (p.image && !fs.existsSync(path.join(root, "img", p.image))) fail(p.name + ": picture img/" + p.image + " not found");
  });
});

fs.readdirSync(root).filter((f) => f.endsWith(".html")).forEach((page) => {
  const html = read(page);
  [...html.matchAll(/href="([^"#?]+)"/g)].map((m) => m[1]).forEach((href) => {
    if (/^(https?:|mailto:|tel:)/.test(href)) return;
    if (!fs.existsSync(path.join(root, href))) fail(page + " links to " + href + " which does not exist");
  });
});

console.log(problems ? problems + " problem(s) found." : "All good: products, pictures and page links look fine.");
process.exit(problems ? 1 : 0);
