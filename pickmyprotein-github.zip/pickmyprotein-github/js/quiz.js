/* ============================================================
   PickMyProtein - QUIZ CODE
   Needs js/products.js to be loaded first (it holds the data).
   Sections:
     1. Icons
     2. Questions and answer options
     3. The visitor's answers
     4. Calculations (protein, calories, best powder)
     5. Choosing which products to show
     6. Page pieces (HTML builders)
     7. Starting the quiz and handling clicks
   ============================================================ */
"use strict";

/* ---------- 1. ICONS (small drawings used on the results page) ---------- */
const ICONS = {
  dumbbell: '<path d="M17.596 12.768a2 2 0 1 0 2.829-2.829l-1.768-1.767a2 2 0 0 0 2.828-2.829l-2.828-2.828a2 2 0 0 0-2.829 2.828l-1.767-1.768a2 2 0 1 0-2.829 2.829z"/><path d="m2.5 21.5 1.4-1.4"/><path d="m20.1 3.9 1.4-1.4"/><path d="M5.343 21.485a2 2 0 1 0 2.829-2.828l1.767 1.768a2 2 0 1 0 2.829-2.829l-6.364-6.364a2 2 0 1 0-2.829 2.829l1.768 1.767a2 2 0 0 0-2.828 2.829z"/><path d="m9.6 14.4 4.8-4.8"/>',
  zap: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
  moon: '<path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"/>',
  sparkles: '<path d="M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z"/><path d="M20 2v4"/><path d="M22 4h-4"/><circle cx="4" cy="20" r="2"/>',
  leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>',
  flame: '<path d="M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4"/>',
  check: '<path d="M20 6 9 17l-5-5"/>'
};

function icon(name, cssClass) {
  return '<svg class="' + cssClass + '" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[name] + '</svg>';
}

/* ---------- 2. QUESTIONS AND ANSWER OPTIONS ----------
   Each option is [value, title, small text].
   To rename a button, change the title or small text.                    */
const OPTIONS = {
  goal: [
    ["muscle", "Build muscle", "Get stronger"],
    ["fatloss", "Lose fat", "Keep muscle"],
    ["endurance", "Endurance", "Run, ride, swim"],
    ["maintain", "Stay healthy", "General health"]
  ],
  activity: [
    ["sedentary", "Mostly seated", "0–1×/week"],
    ["moderate", "Moderate", "2–3×/week"],
    ["active", "Active", "4–5×/week"],
    ["athlete", "Athlete", "6+×/week"]
  ],
  diet: [
    ["omnivore", "Eat everything"],
    ["vegetarian", "Vegetarian"],
    ["vegan", "Vegan"],
    ["lactose", "Dairy sensitive"]
  ],
  flavour: [
    ["any", "No preference", "Show everything"],
    ["raw", "Unflavoured (raw)", "No added flavour"],
    ["flavoured", "Flavoured", "Chocolate, vanilla…"]
  ],
  priority: [
    ["budget", "Value", "Cost per gram"],
    ["taste", "Taste", "Mixes smoothly"],
    ["clean", "Clean label", "Few ingredients"],
    ["fast", "Fast recovery", "Quick to digest"]
  ]
};

/* The quiz screens, in order. "key" matches OPTIONS (weight is a special screen). */
const QUESTIONS = [
  { key: "weight", title: "What is your body weight?", help: "We use this to work out your protein and calorie targets." },
  { key: "goal", title: "What is your main goal?" },
  { key: "activity", title: "How active are you?" },
  { key: "diet", title: "What is your diet?" },
  { key: "priority", title: "What matters most in a powder?" },
  { key: "flavour", title: "Unflavoured (raw) or flavoured?", help: "Unflavoured powder has no added flavouring, so it suits smoothies, curd or oats. Flavoured powder tastes like a shake on its own." }
];

/* ---------- 3. THE VISITOR'S ANSWERS (starting values) ---------- */
const answers = { weight: 75, unit: "kg", goal: "muscle", activity: "active", diet: "omnivore", priority: "budget", flavour: "any", over65: false };

/* Which screen is showing: "quiz" or "results", and which question. */
const view = { screen: "quiz", step: 0, error: "" };

/* ---------- 4. CALCULATIONS ---------- */
/* Protein: grams per kg of body weight, by goal, then adjusted by activity. */
const PROTEIN_PER_KG = { maintain: 1, endurance: 1.4, fatloss: 1.8, muscle: 1.8 };
const ACTIVITY_ADJUST = { sedentary: -0.2, moderate: 0, active: 0.2, athlete: 0.35 };
/* Calories: a rough estimate = weight x kcal per kg (by activity) x goal factor. */
const KCAL_PER_KG = { sedentary: 30, moderate: 33, active: 36, athlete: 40 };
const GOAL_KCAL_FACTOR = { maintain: 1, endurance: 1.05, fatloss: 0.85, muscle: 1.1 };
const MIN_KCAL = 1400;

function weightInKg(a) {
  return a.unit === "lb" ? a.weight * 0.4536 : a.weight;
}

function proteinTarget(a) {
  let perKg = PROTEIN_PER_KG[a.goal] + ACTIVITY_ADJUST[a.activity];
  if (a.over65) perKg = Math.max(perKg, 1.2);        // people 65+: at least 1.2 g per kg
  perKg = Math.min(Math.max(perKg, 0.8), 2.2);       // keep between 0.8 and 2.2 g per kg
  return Math.round(weightInKg(a) * perKg);
}

function calorieTarget(a) {
  const kcal = Math.max(weightInKg(a) * KCAL_PER_KG[a.activity] * GOAL_KCAL_FACTOR[a.goal], MIN_KCAL);
  return Math.round(kcal / 50) * 50;                 // round to the nearest 50
}

/* Scores every powder type that suits the diet. Highest score = best match. */
function rankPowders(a) {
  return POWDERS
    .filter(function (p) { return p.diets.includes(a.diet); })
    .map(function (p) {
      const fit = a.flavour !== "any" ? (p.flavourFit[a.flavour] || 0) : 0;
      let score = p.scores[a.priority] * 2 + (p.goalBonus[a.goal] || 0) * 1.5 + fit;
      if (a.diet === "lactose" && p.id === "whey-isolate") score += 1;
      const reasons = [p.reasons[a.priority], p.reasons[a.goal]].filter(Boolean);
      if (fit >= 2) reasons.push(a.flavour === "raw" ? "Easy to find unflavoured (raw)." : "Comes in many flavours.");
      if (!reasons.length) reasons.push(p.tag + ".");
      return { powder: p, score: score, reasons: reasons };
    })
    .sort(function (x, y) { return y.score - x.score; });
}

/* ---------- 5. CHOOSING WHICH PRODUCTS TO SHOW ---------- */
/* Products for one powder type, filtered by the flavour answer (max 4 per type). */
function productsFor(powderId) {
  const all = PRODUCTS[powderId];
  if (!all) return null;
  const wanted = answers.flavour;
  if (wanted === "any") {
    const raw = all.filter(function (p) { return p.flavour === "raw"; });
    const flavoured = all.filter(function (p) { return p.flavour !== "raw"; });
    const list = raw.length && flavoured.length ? raw.slice(0, 2).concat(flavoured.slice(0, 2)) : all.slice(0, 4);
    return { list: list, missing: false };
  }
  const match = all.filter(function (p) { return p.flavour === wanted; });
  return match.length ? { list: match.slice(0, 4), missing: false } : { list: all.slice(0, 4), missing: true };
}

const TYPE_NAMES = {
  "whey-concentrate": "Whey concentrate",
  "whey-isolate": "Whey isolate",
  "soy-isolate": "Soy isolate",
  "egg-white": "Egg white",
  "pea-rice": "Plant protein",
  "casein": "Casein"
};

/* ---------- 6. PAGE PIECES (HTML builders) ---------- */
/* Option buttons for one question (the selected one is highlighted). */
function optionButtons(key) {
  return OPTIONS[key].map(function (o) {
    const on = answers[key] === o[0];
    const style = on ? "border-ink bg-ink text-cream shadow-[3px_3px_0_0_var(--color-tomato)]" : "border-ink/15 bg-white hover:border-ink/50";
    const small = o[2] ? '<span class="mt-0.5 block text-xs ' + (on ? "text-cream/70" : "text-ink/55") + '">' + o[2] + "</span>" : "";
    return '<button type="button" data-k="' + key + '" data-v="' + o[0] + '" aria-pressed="' + on + '" class="rounded-2xl border-2 px-3 py-3 text-left transition ' + style + '"><span class="block text-sm font-semibold">' + o[1] + "</span>" + small + "</button>";
  }).join("");
}

/* The two big numbers: daily protein and calories. */
function targetCard() {
  const protein = proteinTarget(answers);
  const kcal = calorieTarget(answers);
  return `<div class="relative overflow-hidden rounded-[2rem] bg-ink p-7 text-cream">
<p class="text-sm uppercase tracking-[0.2em] text-cream/60">Your daily target</p>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:22px;margin-top:20px">
<div><p class="text-sm text-cream/60">Protein</p><p class="font-display font-extrabold leading-none tracking-tight" style="font-size:2.9rem;margin-top:6px">${protein || 0}<span class="ml-1 text-2xl text-cream/60">g</span></p><p class="mt-2 text-sm text-cream/75">of protein a day</p></div>
<div><p class="text-sm text-cream/60">Calories</p><p class="font-display font-extrabold leading-none tracking-tight" style="font-size:2.9rem;margin-top:6px">${kcal.toLocaleString("en-IN")}<span class="ml-1 text-2xl text-cream/60">kcal</span></p><p class="mt-2 text-sm text-cream/75">of energy a day</p></div>
</div>
<p class="mt-5 text-xs text-cream/50">Calories are a rough guide from your weight, activity and goal.</p>
</div>`;
}

/* The recommended powder type, with reasons. */
function bestMatchCard(best) {
  const p = best.powder;
  const ticks = best.reasons.map(function (r) {
    return '<li class="flex gap-2">' + icon("check", "mt-0.5 h-5 w-5 shrink-0 text-tomato") + "<span>" + r + "</span></li>";
  }).join("");
  return `<div class="rounded-[2rem] border-2 border-ink bg-lime p-7 shadow-[6px_6px_0_0_var(--color-ink)]">
<p class="text-sm font-semibold uppercase tracking-[0.2em] text-ink/60">Your best match</p>
<div class="mt-3 flex items-start gap-4"><div class="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-ink text-lime">${icon(p.icon, "h-7 w-7")}</div><div><h3 class="font-display text-3xl font-extrabold leading-tight">${p.name}</h3><p class="text-ink/70">${p.tag}</p></div></div>
<ul class="mt-5 space-y-2">${ticks}</ul>
<dl class="mt-5 grid grid-cols-2 gap-3 text-sm"><div class="rounded-xl bg-white/60 p-3"><dt class="text-ink/55">Per scoop</dt><dd class="font-semibold">${p.perScoop}</dd></div><div class="rounded-xl bg-white/60 p-3"><dt class="text-ink/55">Best time</dt><dd class="font-semibold">${p.bestTime}</dd></div></dl>
<p class="mt-4 text-sm text-ink/70"><b>Watch out:</b> ${p.watchOut}</p>
</div>`;
}

/* "Also worth a look": the next 3 powder types. */
function alsoCard(best, others) {
  if (!others.length) return "";
  const rows = others.slice(0, 3).map(function (n) {
    return `<li class="flex items-center gap-3 py-3" style="flex-wrap:wrap">${icon(n.powder.icon, "h-5 w-5 text-tomato")}<div class="flex-1"><p class="font-semibold">${n.powder.name}</p><p class="text-sm text-ink/60">${n.powder.tag}</p></div><span class="rounded-full bg-cream px-3 py-1 text-xs font-semibold">${Math.round(n.score / best.score * 100)}% match</span></li>`;
  }).join("");
  return `<div class="rounded-[2rem] border-2 border-ink/15 bg-white p-6"><p class="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-ink/50">Also worth a look</p><ul class="divide-y divide-ink/10">${rows}</ul></div>`;
}

/* One product card in the Recommendations grid. */
function productCard(item) {
  const p = item.product;
  const picture = SITE.showImages && p.image
    ? '<img src="img/' + p.image + '" alt="' + p.name + '" width="220" height="220" loading="lazy" style="max-height:220px;max-width:100%;width:auto;height:auto;object-fit:contain">'
    : '<span style="font:700 64px Fraunces,Georgia,serif;color:var(--color-tomato)">' + p.brand[0] + "</span>";
  const bestTag = item.isBest ? '<span style="position:absolute;top:12px;left:12px;z-index:1;background:var(--color-lime);color:var(--ink);font-size:11px;font-weight:700;border-radius:999px;padding:3px 10px">Best match</span>' : "";
  return `<li style="list-style:none"><a href="${amazonLink(p)}" target="_blank" rel="sponsored noopener noreferrer" style="position:relative;display:flex;flex-direction:column;height:100%;color:inherit;text-decoration:none;background:#fff;border:1px solid rgba(42,26,15,.12);border-radius:16px;padding:18px;box-shadow:0 10px 30px -18px rgba(42,26,15,.4)">${bestTag}<span style="display:grid;place-items:center;height:230px;background:#fff">${picture}</span><span style="margin-top:14px;font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--brand-dark)">${p.brand}</span><span style="margin-top:6px;font-size:16px;font-weight:600;line-height:1.35;min-height:44px">${p.name}</span><span style="margin-top:4px;font-size:13px;color:rgba(42,26,15,.6)">${TYPE_NAMES[item.powderId]} · ${p.flavourLabel || (p.flavour === "raw" ? "Unflavoured" : "Flavoured")}</span><span style="margin-top:auto;padding-top:16px"><span style="display:block;text-align:center;background:var(--color-tomato);color:var(--ink);border-radius:10px;padding:12px;font-weight:700">View on Amazon</span></span></a></li>`;
}

/* The "PickMyProtein Recommendations" grid: best-match products first, then the next types. */
function recommendations() {
  const ranked = rankPowders(answers);
  const seen = {};
  let items = [];
  let missing = false;
  ranked.forEach(function (r, index) {
    const found = productsFor(r.powder.id);
    if (!found) return;
    if (found.missing) missing = true;
    found.list.forEach(function (p) {
      const link = amazonLink(p);
      if (!seen[link]) { seen[link] = true; items.push({ product: p, powderId: r.powder.id, isBest: index === 0 }); }
    });
  });
  items = items.slice(0, SITE.maxCards);
  if (!items.length) return "";
  const note = missing ? '<p class="mt-4 text-center text-xs text-ink/55">Some types have no ' + (answers.flavour === "raw" ? "unflavoured" : "flavoured") + " option linked yet, so we show the other choice for them.</p>" : "";
  return `<section style="margin-top:44px">
<div style="text-align:center"><h2 class="font-display text-3xl font-bold tracking-tight sm:text-4xl">PickMyProtein Recommendations</h2><p class="mt-2 text-ink/60">Compare and find the best protein powder suited for your goals</p></div>
<ul style="display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:20px;padding:0;margin:28px 0 0">${items.map(productCard).join("")}</ul>
${note}<p class="mt-3 text-center text-xs text-ink/55">Affiliate links: I may earn a commission at no extra cost to you.</p>
</section>`;
}

/* The weight question (number box, kg/lb switch, "65 or older" tick box). */
function weightQuestion() {
  const unitButtons = ["kg", "lb"].map(function (u) {
    return '<button type="button" data-unit="' + u + '" class="rounded-full px-4 py-1 text-sm font-semibold ' + (answers.unit === u ? "bg-ink text-cream" : "") + '">' + u + "</button>";
  }).join("");
  const error = view.error ? '<p class="mt-3 text-sm font-semibold" style="color:var(--brand-dark)">' + view.error + "</p>" : "";
  return `<div class="flex flex-wrap items-center gap-3"><div class="flex items-baseline gap-2 rounded-2xl border-2 border-ink/15 bg-white px-4 py-2 focus-within:border-ink"><input id="w" type="number" inputmode="decimal" min="30" max="400" value="${answers.weight}" class="w-24 bg-transparent font-display text-3xl font-bold outline-none" aria-label="Body weight"><span class="text-ink/50">${answers.unit}</span></div><div class="flex rounded-full border-2 border-ink p-1">${unitButtons}</div></div><label class="mt-5 flex cursor-pointer items-center gap-2 text-sm text-ink/70"><input id="o65" type="checkbox" ${answers.over65 ? "checked" : ""} class="h-4 w-4">I'm 65 or older</label>${error}`;
}

const BUTTON_OUTLINE = "rounded-full border-2 border-ink px-5 py-2 text-sm font-semibold";

/* One quiz screen (question, options, Back / Next buttons, progress bar). */
function quizScreen() {
  const q = QUESTIONS[view.step];
  const isLast = view.step === QUESTIONS.length - 1;
  const percent = Math.round((view.step + 1) / QUESTIONS.length * 100);
  const body = q.key === "weight" ? weightQuestion() : '<div class="grid grid-cols-2 gap-2 sm:grid-cols-4">' + optionButtons(q.key) + "</div>";
  const help = q.help ? '<p class="mt-2 text-ink/60">' + q.help + "</p>" : "";
  return `<div class="mx-auto max-w-2xl rounded-[2rem] border-2 border-ink bg-white/70 p-6 sm:p-8">
<div class="flex items-center justify-between text-sm text-ink/60"><span>Question ${view.step + 1} of ${QUESTIONS.length}</span><span>${percent}%</span></div>
<div class="mt-2 overflow-hidden rounded-full bg-ink/10" style="height:8px"><div class="rounded-full bg-tomato" style="height:8px;width:${percent}%;transition:width .4s"></div></div>
<h2 class="mt-7 font-display text-3xl font-bold tracking-tight">${q.title}</h2>${help}
<div class="mt-6">${body}</div>
<div class="mt-8 flex items-center justify-between gap-3"><button type="button" data-nav="back" class="${BUTTON_OUTLINE}" style="visibility:${view.step ? "visible" : "hidden"}">← Back</button><button type="button" data-nav="next" class="rounded-full bg-tomato px-7 py-3 font-semibold" style="color:var(--ink)">${isLast ? "See my results" : "Next →"}</button></div>
</div>`;
}

/* The final results screen. */
function resultsScreen() {
  const ranked = rankPowders(answers);
  const best = ranked[0];
  const others = ranked.slice(1);
  return `<div class="mx-auto max-w-6xl">
<div class="flex flex-wrap items-center justify-between gap-3"><h2 class="font-display text-3xl font-bold tracking-tight">Your results</h2><button type="button" data-nav="retake" class="${BUTTON_OUTLINE}">← Retake the quiz</button></div>
<div class="mt-6 grid gap-5 lg:grid-cols-2 lg:items-start" aria-live="polite"><div class="space-y-5">${targetCard()}${alsoCard(best, others)}</div><div>${bestMatchCard(best)}</div></div>
${recommendations()}
</div>`;
}

/* BOOT: everything below needs the browser page (it is skipped by the test script). */
/* ---------- 7. STARTING THE QUIZ AND HANDLING CLICKS ---------- */
const root = document.getElementById("app");

function render() {
  root.className = "";
  root.innerHTML = view.screen === "quiz" ? quizScreen() : resultsScreen();
}

/* Change the screen, redraw, and scroll back to the top of the quiz. */
function go(change) {
  change();
  render();
  root.scrollIntoView({ behavior: "smooth", block: "start" });
}

root.addEventListener("click", function (e) {
  const button = e.target.closest("button");
  if (!button) return;

  if (button.dataset.k) {                       // an answer button was clicked
    answers[button.dataset.k] = button.dataset.v;
    render();
  } else if (button.dataset.unit && button.dataset.unit !== answers.unit) {   // kg / lb switch
    const unit = button.dataset.unit;
    answers.weight = Math.round(unit === "lb" ? answers.weight / 0.4536 : answers.weight * 0.4536);
    answers.unit = unit;
    view.error = "";
    render();
  } else if (button.dataset.nav === "next") {
    const kg = weightInKg(answers);
    if (QUESTIONS[view.step].key === "weight" && !(kg >= 30 && kg <= 300)) {
      view.error = "Please enter a weight between 30 and 300 kg (66 to 660 lb).";
      render();
      return;
    }
    view.error = "";
    go(function () {
      if (view.step < QUESTIONS.length - 1) view.step++;
      else view.screen = "results";
    });
  } else if (button.dataset.nav === "back") {
    go(function () { view.step = Math.max(0, view.step - 1); });
  } else if (button.dataset.nav === "retake") {
    go(function () { view.screen = "quiz"; view.step = 0; });
  }
});

root.addEventListener("input", function (e) {
  if (e.target.id === "w") answers.weight = Number(e.target.value);
});
root.addEventListener("change", function (e) {
  if (e.target.id === "o65") answers.over65 = e.target.checked;
});

render();
