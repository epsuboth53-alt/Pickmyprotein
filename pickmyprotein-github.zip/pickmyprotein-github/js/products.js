/* ============================================================
   PickMyProtein - DATA FILE (edit this file to change products)
   ------------------------------------------------------------
   1. SITE      - your Amazon tracking ID and a few switches
   2. POWDERS   - the 6 powder types the quiz can recommend
   3. PRODUCTS  - the Amazon product cards shown on the results page
   After editing, open index.html in your browser to test.
   ============================================================ */

/* ---------- 1. SITE SETTINGS ---------- */
const SITE = {
  associateTag: "pickmyprote03-21",  // your Amazon Associates Store ID
  showImages: true,                  // false = hide product pictures (see README, "Product pictures")
  maxCards: 8                        // most product cards shown on the results page
};

/* ---------- 2. POWDER TYPES ----------
   id          short name used in PRODUCTS below
   diets       which diet answers this type suits
   scores      0-5 points for each "what matters most" answer
   goalBonus   extra points for a goal
   flavourFit  how often it is sold unflavoured ("raw") or flavoured (0-2)
   reasons     the tick-list sentences shown for each answer          */
const POWDERS = [
  {
    id: "whey-concentrate",
    icon: "dumbbell",
    name: "Whey Concentrate",
    tag: "The everyday all-rounder",
    perScoop: "~22–24 g protein · 120 kcal",
    bestTime: "Post-workout or with breakfast",
    watchOut: "Contains some lactose — not ideal if dairy upsets you.",
    diets: ["omnivore","vegetarian"],
    scores: { budget: 5, taste: 5, clean: 3, fast: 4 },
    goalBonus: { muscle: 2, maintain: 1 },
    flavourFit: { raw: 2, flavoured: 2 },
    reasons: {
      budget: "The cheapest grams of high-quality protein you can buy.",
      taste: "Creamy, mixes easily and comes in the most flavours.",
      muscle: "Rich in leucine, the amino acid that switches on muscle building."
    }
  },
  {
    id: "whey-isolate",
    icon: "zap",
    name: "Whey Isolate",
    tag: "Lean, fast and nearly lactose-free",
    perScoop: "~25–27 g protein · 110 kcal",
    bestTime: "Straight after training",
    watchOut: "Costs roughly 20–40% more than concentrate.",
    diets: ["omnivore","vegetarian","lactose"],
    scores: { budget: 3, taste: 4, clean: 4, fast: 5 },
    goalBonus: { fatloss: 2, muscle: 1 },
    flavourFit: { raw: 1, flavoured: 2 },
    reasons: {
      fast: "Digests in about an hour — the quickest protein after training.",
      fatloss: "Very low in carbs and fat, so more protein per calorie.",
      clean: "Filtered to over 90% protein with very little else."
    }
  },
  {
    id: "casein",
    icon: "moon",
    name: "Micellar Casein",
    tag: "Slow-release, keeps you full",
    perScoop: "~24 g protein · 120 kcal",
    bestTime: "Before bed or as a filling snack",
    watchOut: "Thick texture, and not the one to take right after training.",
    diets: ["omnivore","vegetarian"],
    scores: { budget: 3, taste: 3, clean: 4, fast: 1 },
    goalBonus: { fatloss: 2, muscle: 1 },
    flavourFit: { raw: 1, flavoured: 2 },
    reasons: {
      fatloss: "Digests slowly and keeps you feeling full for hours.",
      muscle: "Feeds your muscles overnight while you sleep."
    }
  },
  {
    id: "egg-white",
    icon: "sparkles",
    name: "Egg White Protein",
    tag: "Dairy-free, but still animal protein",
    perScoop: "~24 g protein · 110 kcal",
    bestTime: "Any time, also good for baking",
    watchOut: "Fewer flavours and slightly foamy when shaken.",
    diets: ["omnivore","vegetarian","lactose"],
    scores: { budget: 2, taste: 2, clean: 5, fast: 3 },
    goalBonus: { maintain: 1, endurance: 1 },
    flavourFit: { raw: 2, flavoured: 1 },
    reasons: {
      clean: "Usually a single ingredient: dried egg whites.",
      maintain: "A complete protein with no dairy at all."
    }
  },
  {
    id: "pea-rice",
    icon: "leaf",
    name: "Pea + Rice Blend",
    tag: "A complete plant protein",
    perScoop: "~21–23 g protein · 120 kcal",
    bestTime: "Post-workout or in smoothies",
    watchOut: "Earthier taste, so blending with fruit helps.",
    diets: ["omnivore","vegetarian","vegan","lactose"],
    scores: { budget: 4, taste: 3, clean: 5, fast: 3 },
    goalBonus: { endurance: 2, maintain: 1 },
    flavourFit: { raw: 2, flavoured: 1 },
    reasons: {
      clean: "Allergen-friendly and usually free of gums and fillers.",
      endurance: "Easy on the stomach and naturally high in iron and arginine.",
      budget: "The best-value plant option per gram of protein."
    }
  },
  {
    id: "soy-isolate",
    icon: "flame",
    name: "Soy Isolate",
    tag: "The plant protein closest to whey",
    perScoop: "~25 g protein · 110 kcal",
    bestTime: "Post-workout",
    watchOut: "Skip it if you have a soy allergy.",
    diets: ["omnivore","vegetarian","vegan","lactose"],
    scores: { budget: 5, taste: 4, clean: 3, fast: 4 },
    goalBonus: { muscle: 1, fatloss: 1 },
    flavourFit: { raw: 2, flavoured: 1 },
    reasons: {
      muscle: "A complete amino acid profile that rivals whey for muscle gain.",
      budget: "Inexpensive and widely available.",
      taste: "Smooth and neutral, so it mixes easily."
    }
  }
];

/* ---------- 3. PRODUCTS ----------
   One block per powder type. Order = order shown.
   flavour      "raw" = unflavoured, "flavoured" = has a flavour
   asin, linkId copy them from your Amazon SiteStripe link (see README)
   image        file name inside the img/ folder, or "" for none            */
const PRODUCTS = {
  // ----- Whey concentrate -----
  "whey-concentrate": [
    {
      brand: "AS-IT-IS",
      name: "AS-IT-IS Nutrition Whey Protein Concentrate 80%",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B079SZJJDR",
      linkId: "33a5562df5760f0e92efff36552681d4",
      image: "B079SZJJDR.jpg"
    },
    {
      brand: "Denzour",
      name: "Denzour Nutrition Denz-Raw Whey Protein",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B0C9JWXLH4",
      linkId: "0490dfb6e9daf71d85b8f52abc4ec656",
      image: "B0C9JWXLH4.jpg"
    },
    {
      brand: "MuscleBlaze",
      name: "MuscleBlaze 100% Clean Raw Whey Concentrate",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B06XGNT22C",
      linkId: "047122cc03b79d184c8949803bb1b656",
      image: "B06XGNT22C.jpg"
    },
    {
      brand: "Wellbeing Nutrition",
      name: "Wellbeing Nutrition 100% Raw Whey Protein Concentrate",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B0DMNWWH5S",
      linkId: "75d30cd491bf0df4c0d11475edaf4df1",
      image: "B0DMNWWH5S.jpg"
    },
    {
      brand: "MuscleBlaze",
      name: "MuscleBlaze Raw Whey Protein",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B0BPH457FG",
      linkId: "83f8b340db146134b771c0c41b2fde38",
      image: "B0BPH457FG.jpg"
    },
    {
      brand: "NAKPRO",
      name: "NAKPRO Whey Gold Protein Concentrate",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B07M7YZ57R",
      linkId: "3e7d5870f2a4a05b0ea51b89320722f4",
      image: "B07M7YZ57R.jpg"
    },
    {
      brand: "Yogabar",
      name: "Yogabar Pro Clean Whey Concentrate",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B0DV5D8355",
      linkId: "8a73295a10fb681f30da31e7ebb3f550",
      image: "B0DV5D8355.jpg"
    },
    {
      brand: "AS-IT-IS",
      name: "AS-IT-IS Nutrition ATOM Whey Protein",
      flavour: "flavoured",
      flavourLabel: "Double rich chocolate",
      asin: "B09DKFPQ91",
      linkId: "12c480afcf104dc2ba493b6cb4d86666",
      image: "B09DKFPQ91.jpg"
    },
    {
      brand: "MuscleBlaze",
      name: "MuscleBlaze Biozyme Performance Whey",
      flavour: "flavoured",
      flavourLabel: "Chocolate",
      asin: "B091HTLXL3",
      linkId: "7a3847fe98f4f43702066e6ef65deb36",
      image: ""
    }
  ],

  // ----- Whey isolate -----
  "whey-isolate": [
    {
      brand: "Optimum Nutrition",
      name: "Optimum Nutrition Gold Standard 100% Whey",
      flavour: "flavoured",
      flavourLabel: "Alphonso mango (isolate-led whey blend)",
      asin: "B0D1VJ3C7R",
      linkId: "94c4eeb3c3d722ea89b07614e6111dcc",
      image: "B0D1VJ3C7R.jpg"
    }
  ],

  // ----- Soy isolate -----
  "soy-isolate": [
    {
      brand: "AS-IT-IS",
      name: "AS-IT-IS Nutrition Soy Protein Isolate",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B07ZM7CW2Z",
      linkId: "008d21a681897ef9fc062bff7ba2794e",
      image: "B07ZM7CW2Z.jpg"
    },
    {
      brand: "Pure Nutrition",
      name: "Pure Nutrition Soy Protein Isolate 90%",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B0DKTNQRWH",
      linkId: "849b06f3d03abde14ba13fbaf95b7b74",
      image: "B0DKTNQRWH.jpg"
    }
  ],

  // ----- Egg white -----
  "egg-white": [
    {
      brand: "Tata 1mg",
      name: "Tata 1mg Egg White Protein",
      flavour: "flavoured",
      flavourLabel: "Chocolate",
      asin: "B0HFKFJ637",
      linkId: "e2a92537f09e93de4455c2ed60cb615f",
      image: "B0HFKFJ637.jpg"
    }
  ],

  // ----- Plant protein (pea / rice) -----
  "pea-rice": [
    {
      brand: "OZiva",
      name: "OZiva Organic Plant Protein",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B09VGSVRXH",
      linkId: "1ef372818766a7b47beed51b165d4018",
      image: "B09VGSVRXH.jpg"
    },
    {
      brand: "Origin Nutrition",
      name: "Origin Nutrition Daily Plant Protein",
      flavour: "raw",
      flavourLabel: "Unflavoured",
      asin: "B08X1T9THR",
      linkId: "e357994c9e8845eb80ea088e44396445",
      image: "B08X1T9THR.jpg"
    },
    {
      brand: "TrueBasics",
      name: "TrueBasics Clean Plant Protein",
      flavour: "flavoured",
      flavourLabel: "Chocolate",
      asin: "B0FMRVH8QB",
      linkId: "fd149a124b7ebbea605565d8f1576046",
      image: "B0FMRVH8QB.jpg"
    },
    {
      brand: "No Nonsense",
      name: "No Nonsense Plant Protein",
      flavour: "flavoured",
      flavourLabel: "Indonesian cacao",
      asin: "B0DM1X4FLG",
      linkId: "711ee4a47bb186fd27345b6cd0cca48e",
      image: "B0DM1X4FLG.jpg"
    },
    {
      brand: "Nutrabay",
      name: "Nutrabay Gold Hydrolyzed Pea Protein",
      flavour: "flavoured",
      flavourLabel: "Flavoured",
      asin: "B0G44ZRYRX",
      linkId: "c44e8de84fba0ec23c3e7008713f1bdc",
      image: "B0G44ZRYRX.jpg"
    }
  ]
};

/* Builds the Amazon affiliate link for a product (do not edit). */
function amazonLink(p) {
  return "https://www.amazon.in/dp/" + p.asin + "?th=1&linkCode=ll2&tag=" + SITE.associateTag + "&linkId=" + p.linkId + "&ref_=as_li_ss_tl";
}
